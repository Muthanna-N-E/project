export class Employee {
    first_name!:string;
    middle_name!:string;
    last_name!:string;
    father_name!:string;
    mother_name!:string;
    date!:string;
    emp_id!:string;
    adhar_card!:string;
    pan_card!:string;
    gender!:string;
    lang!:string;
    phno!:string;
    address!:string;
    email_id!:string


}
