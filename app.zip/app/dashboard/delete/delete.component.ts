import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { combineLatestInit } from 'rxjs/internal/observable/combineLatest';
import { Employee } from 'src/app/employee';
import { EmployeeService } from 'src/app/employee.service';
import * as alertify from 'alertifyjs';

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {
   
  employee!:Employee[];
  constructor(private httpClient:HttpClient) { }

  ngOnInit(): void {
  }
  onSubmit(data:Employee){
    this.httpClient.post('http://localhost:8090/emp/empDelete/'+`${data.emp_id}`,data).subscribe((result)=>{
      console.warn("result",result);
      console.warn(data);
    })
    alertify.alert('Deleted!!', 'Employee Details is successfully removed');
  }

}
